package com.ghostbuddy

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

/**
 * Conversazione in memoria: sopravvive alla chiusura della finestra della chat
 * (finché l'app resta in vita), così puoi richiuderla e riaprirla senza perdere nulla.
 */
object ChatStore {
    const val DEFAULT_MODEL = "gemini-2.5-flash"

    class Attachment(val name: String, val block: JSONObject)

    class UiMsg(
        val fromUser: Boolean,
        val text: String,
        val note: String? = null,
        val isError: Boolean = false
    )

    val ui = ArrayList<UiMsg>()
    val api = JSONArray()

    @Volatile
    var busy = false

    var listener: (() -> Unit)? = null

    private var gen = 0
    private val main = Handler(Looper.getMainLooper())

    fun clear() {
        gen++
        busy = false
        ui.clear()
        while (api.length() > 0) api.remove(0)
        listener?.invoke()
    }

    fun send(appCtx: Context, text: String, atts: List<Attachment>) {
        val prefs = appCtx.getSharedPreferences("ghost", Context.MODE_PRIVATE)
        val key = prefs.getString("api_key", "").orEmpty()
        val model = prefs.getString("model", DEFAULT_MODEL).orEmpty().ifEmpty { DEFAULT_MODEL }
        val note: String? = if (atts.isEmpty()) null else atts.joinToString(", ") { it.name }

        ui.add(UiMsg(true, text, note))
        if (key.isEmpty()) {
            ui.add(UiMsg(false, "Manca la chiave API: inseriscila da ⚙.", isError = true))
            listener?.invoke()
            return
        }

        val content = JSONArray()
        for (a in atts) content.put(a.block)
        val shown = if (text.isBlank()) "Guarda l'allegato." else text
        content.put(JSONObject().put("type", "text").put("text", shown))
        api.put(JSONObject().put("role", "user").put("content", content))

        busy = true
        listener?.invoke()
        GhostBus.react(GhostReaction.CURIOUS)

        val myGen = gen
        val request = GeminiClient.forRequest(api)
        Thread {
            var reply: String? = null
            var error: String? = null
            try {
                reply = GeminiClient.send(key, model, request)
            } catch (e: Exception) {
                error = e.message ?: "Errore sconosciuto"
            }
            val r = reply
            val er = error
            main.post { finish(myGen, r, er) }
        }.start()
    }

    private fun finish(myGen: Int, reply: String?, error: String?) {
        if (myGen != gen) return
        busy = false
        if (!reply.isNullOrEmpty()) {
            api.put(JSONObject().put("role", "assistant").put("content", reply))
            ui.add(UiMsg(false, reply))
            GhostBus.react(GhostReaction.MESSAGE)
        } else {
            // toglie il messaggio rimasto senza risposta, così si può riprovare
            if (api.length() > 0) api.remove(api.length() - 1)
            ui.add(UiMsg(false, error ?: "Risposta vuota", isError = true))
            GhostBus.react(GhostReaction.MISSED_CALL)
        }
        listener?.invoke()
    }
}

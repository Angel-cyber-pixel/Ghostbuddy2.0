package com.ghostbuddy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import com.ghostbuddy.GhostReaction.*
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

// Fantasmino originale in pixel art: 12 colonne x 13 righe, '#' = corpo.
private val BODY = arrayOf(
    "...######...",
    "..########..",
    ".##########.",
    "############",
    "############",
    "############",
    "############",
    "############",
    "############",
    "############",
    "############",
    "#.##.##.##.#",
    "#..#..#..#..",
)

private val INK = 0xFF2B2640.toInt()
private val SHADOW = 0xFF000000.toInt()
private val BODY_COLOR = 0xFFF4F4FF.toInt()
private val CHEEK_HOT = 0xFFFF2E63.toInt()
private val CHEEK_SOFT = 0xFFFF9EC0.toInt()
private val TEAR = 0xFF6FC3FF.toInt()

private val EMOJI = mapOf(
    BLUSH to "💘",
    CALL to "📞",
    MISSED_CALL to "📵",
    MESSAGE to "💬",
    SOCIAL to "❤️",
    EMAIL to "✉️",
    ALARM to "⏰",
    MONEY to "💰",
    MUSIC to "🎵",
    CURIOUS to "❗"
)

/**
 * Il fantasmino. Un tocco apre la chat (onTap).
 * Le reazioni cambiano occhi, bocca, braccia e aggiungono un'emoji sopra la testa.
 */
class GhostView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onTap: (() -> Unit)? = null

    private var reaction = IDLE
    private var startMs = SystemClock.uptimeMillis()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    init {
        isClickable = true
        setOnClickListener { onTap?.invoke() }
    }

    fun react(r: GhostReaction) {
        reaction = r
        startMs = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun cell(canvas: Canvas, x: Float, y: Float, c: Float, color: Int, alpha: Int = 255) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = alpha.coerceIn(0, 255)
        canvas.drawRect(x, y, x + c, y + c, paint)
    }

    private fun arm(canvas: Canvas, pivotX: Float, pivotY: Float, c: Float, angle: Float) {
        canvas.save()
        canvas.rotate(angle, pivotX, pivotY)
        rect.set(pivotX - 0.7f * c, pivotY, pivotX + 0.7f * c, pivotY + 3f * c)
        paint.style = Paint.Style.FILL
        paint.color = BODY_COLOR
        paint.alpha = 255
        canvas.drawRoundRect(rect, 0.7f * c, 0.7f * c, paint)
        canvas.restore()
    }

    /** Angoli (sinistra, destra) delle braccia in base alla reazione. */
    private fun armAngles(t: Float): Pair<Float, Float> = when (reaction) {
        BLUSH -> -115f to 115f
        CALL, ALARM -> {
            val s = sin(t * 30f) * 20f
            (140f + s) to (-140f - s)
        }
        MESSAGE, SOCIAL, MONEY, MUSIC -> {
            val s = sin(t * 8f) * 15f
            (140f + s) to (-140f - s)
        }
        MISSED_CALL -> 12f to -12f
        EMAIL -> -25f to 25f
        else -> {
            val s = sin(t * 2.2f) * 8f
            s to -s
        }
    }

    private fun floatEmoji(canvas: Canvas, emoji: String, e: Float, cx: Float, top: Float, c: Float) {
        for (i in 0..1) {
            val phase = (e * 0.6f + i * 0.5f) % 1f
            val x = cx + sin(e * 2.5f + i * 2f) * 0.8f * c + (i * 2 - 1) * 0.8f * c
            val y = top - phase * 2.5f * c
            textPaint.textSize = 2.2f * c
            textPaint.alpha = (255 * (1f - phase)).toInt().coerceIn(0, 255)
            canvas.drawText(emoji, x, y, textPaint)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        if (reaction != IDLE && reaction.durationMs > 0 && now - startMs > reaction.durationMs) {
            reaction = IDLE
        }
        val t = now / 1000f
        val e = (now - startMs) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()
        val c = min(w / 16f, h / 18f)
        val cx = w / 2f
        val blink = (now % 3400L) < 140L

        // movimento per reazione
        var dx = 0f
        var dy = sin(t * 2.2f) * 0.35f * c
        var rot = 0f
        when (reaction) {
            CALL -> dx = sin(t * 45f) * 0.15f * c
            ALARM -> if (e < 0.5f) dy -= sin(e / 0.5f * PI.toFloat()) * 1.2f * c else dx = sin(t * 40f) * 0.1f * c
            MUSIC -> rot = sin(t * 5f) * 8f
            BLUSH -> dx = sin(t * 3f) * 0.12f * c
            MISSED_CALL -> dy += 0.6f * c
            CURIOUS -> if (e < 0.4f) dy -= sin(e / 0.4f * PI.toFloat()) * 0.8f * c
            MESSAGE, SOCIAL, MONEY, EMAIL -> dy -= abs(sin(e * 6f)) * 0.5f * c
            IDLE -> {}
        }

        val ox = cx - 6f * c + dx
        val baseOy = 3.5f * c
        val oy = baseOy + dy

        // ombra a terra, più piccola quando il fantasma sale
        val lift = min(1f, abs(dy) / (1.2f * c))
        val sw = 4.2f * c * (1f - 0.25f * lift)
        paint.style = Paint.Style.FILL
        paint.color = SHADOW
        paint.alpha = (110 * (1f - lift)).toInt()
        rect.set(cx - sw, baseOy + 13.6f * c, cx + sw, baseOy + 14.4f * c)
        canvas.drawOval(rect, paint)

        canvas.save()
        canvas.rotate(rot, cx, oy + 6f * c)

        // braccia (dietro al corpo)
        val (la, ra) = armAngles(t)
        arm(canvas, ox - 0.2f * c, oy + 5f * c, c, la)
        arm(canvas, ox + 12.2f * c, oy + 5f * c, c, ra)

        // corpo con ombra pixel
        for (r in BODY.indices) {
            for (col in BODY[r].indices) {
                if (BODY[r][col] == '#') cell(canvas, ox + col * c + 0.25f * c, oy + r * c + 0.25f * c, c, SHADOW, 60)
            }
        }
        for (r in BODY.indices) {
            for (col in BODY[r].indices) {
                if (BODY[r][col] == '#') cell(canvas, ox + col * c, oy + r * c, c, BODY_COLOR)
            }
        }

        fun put(col: Int, row: Int, color: Int = INK) = cell(canvas, ox + col * c, oy + row * c, c, color)

        // guance
        val cheekColor = if (reaction == BLUSH) CHEEK_HOT else CHEEK_SOFT
        val cheekAlpha = if (reaction == BLUSH) (200 + 55 * sin(t * 6f)).toInt() else 150
        for (col in listOf(1, 2, 9, 10)) cell(canvas, ox + col * c, oy + 7 * c, c, cheekColor, cheekAlpha)

        // occhi
        val closed = blink || reaction == BLUSH || reaction == MUSIC || reaction == MESSAGE
        val eyeRows = if (closed) listOf(6) else listOf(5, 6)
        for (r in eyeRows) {
            for (col in listOf(3, 4, 7, 8)) put(col, r)
        }

        // lacrime
        if (reaction == MISSED_CALL) {
            val drop = (e * 1.2f) % 1f
            for (col in listOf(3, 8)) {
                cell(canvas, ox + col * c, oy + (7f + drop) * c, c, TEAR, (255 * (1f - drop)).toInt())
            }
        }

        // bocca
        when (reaction) {
            CALL, ALARM -> { put(5, 8); put(6, 8); put(5, 9); put(6, 9) }
            MISSED_CALL -> { put(5, 8); put(6, 8); put(4, 9); put(7, 9) }
            MESSAGE, SOCIAL, MONEY, MUSIC, EMAIL -> { put(4, 8); put(7, 8); put(5, 9); put(6, 9) }
            else -> { put(5, 8); put(6, 8) }
        }

        canvas.restore()

        // emoji sopra la testa
        EMOJI[reaction]?.let { floatEmoji(canvas, it, e, cx, oy - 0.5f * c, c) }

        postInvalidateDelayed(33)
    }
}

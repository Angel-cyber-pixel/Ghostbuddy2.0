package com.ghostbuddy

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Schermata della chat con il fantasma. La conversazione vive in ChatStore. */
class ChatActivity : Activity() {

    companion object {
        private const val REQ_FILE = 1
        private const val REQ_VOICE = 2
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var settings: LinearLayout
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var attachLabel: TextView
    private val pending = ArrayList<ChatStore.Attachment>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ghost", Context.MODE_PRIVATE)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val fill = LinearLayout.LayoutParams.MATCH_PARENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1E1B2E.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        // barra in alto: titolo, impostazioni, nuova chat
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(
            TextView(this).apply {
                text = "GhostBuddy 👻"
                textSize = 18f
                setTextColor(Color.WHITE)
            },
            LinearLayout.LayoutParams(0, wrap, 1f)
        )
        top.addView(Button(this).apply {
            text = "⚙"
            isAllCaps = false
            setOnClickListener {
                settings.visibility = if (settings.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        })
        top.addView(Button(this).apply {
            text = "Nuova"
            isAllCaps = false
            setOnClickListener { ChatStore.clear() }
        })
        root.addView(top)

        // impostazioni: chiave API e modello
        settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        keyField = EditText(this).apply {
            hint = "Chiave Google AI Studio"
            setText(prefs.getString("api_key", ""))
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9E99C4.toInt())
            textSize = 13f
            isSingleLine = true
        }
        modelField = EditText(this).apply {
            hint = "Modello"
            setText(prefs.getString("model", ChatStore.DEFAULT_MODEL))
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9E99C4.toInt())
            textSize = 13f
            isSingleLine = true
        }
        settings.addView(keyField)
        settings.addView(modelField)
        settings.addView(Button(this).apply {
            text = "Salva"
            isAllCaps = false
            setOnClickListener {
                prefs.edit()
                    .putString("api_key", keyField.text.toString().trim())
                    .putString("model", modelField.text.toString().trim())
                    .apply()
                Toast.makeText(this@ChatActivity, "Impostazioni salvate", Toast.LENGTH_SHORT).show()
                settings.visibility = View.GONE
            }
        })
        root.addView(settings)

        // conversazione
        scroll = ScrollView(this)
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(fill, 0, 1f))

        // allegati in attesa di invio
        attachLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFF9E99C4.toInt())
            visibility = View.GONE
        }
        root.addView(attachLabel)

        // barra di scrittura
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(Button(this).apply {
            text = "📎"
            isAllCaps = false
            setOnClickListener { pickFile() }
        })
        bar.addView(Button(this).apply {
            text = "🎤"
            isAllCaps = false
            setOnClickListener { dictate() }
        })
        input = EditText(this).apply {
            hint = "Scrivi al fantasma..."
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9E99C4.toInt())
        }
        bar.addView(input, LinearLayout.LayoutParams(0, wrap, 1f))
        sendBtn = Button(this).apply {
            text = "➤"
            isAllCaps = false
            setOnClickListener { send() }
        }
        bar.addView(sendBtn)
        root.addView(bar)

        setContentView(root)

        if (ChatStore.ui.isEmpty()) {
            ChatStore.ui.add(
                ChatStore.UiMsg(
                    false,
                    "Boo! Scrivimi, mandami un vocale, un'immagine o un PDF. " +
                        "Per rispondere ho bisogno della chiave gratuita di Google AI Studio: aprila con ⚙."
                )
            )
        }
    }

    override fun onResume() {
        super.onResume()
        ChatStore.listener = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() {
        ChatStore.listener = null
        super.onPause()
    }

    private fun render() {
        messages.removeAllViews()
        for (m in ChatStore.ui) {
            val body = if (m.note != null) "${m.text}\n📎 ${m.note}" else m.text
            addBubble(body, m.fromUser, m.isError)
        }
        if (ChatStore.busy) addBubble("...", false, false)
        sendBtn.isEnabled = !ChatStore.busy
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubble(text: String, mine: Boolean, error: Boolean) {
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 16 * d
                setColor(
                    when {
                        error -> 0xFF7A2B3A.toInt()
                        mine -> 0xFF5B4BD6.toInt()
                        else -> 0xFF322C4A.toInt()
                    }
                )
            }
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = (6 * d).toInt()
        }
        messages.addView(tv, lp)
    }

    private fun send() {
        if (ChatStore.busy) return
        val text = input.text.toString().trim()
        if (text.isEmpty() && pending.isEmpty()) return
        val atts = ArrayList(pending)
        pending.clear()
        updateAttachLabel()
        input.setText("")
        ChatStore.send(applicationContext, text, atts)
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
            .setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf", "text/*"))
        startActivityForResult(intent, REQ_FILE)
    }

    private fun dictate() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
        try {
            startActivityForResult(intent, REQ_VOICE)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Riconoscimento vocale non disponibile", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_FILE -> data.data?.let { addAttachment(it) }
            REQ_VOICE -> data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()?.let { input.setText(it) }
        }
    }

    private fun addAttachment(uri: Uri) {
        Thread {
            try {
                val att = Attachments.load(contentResolver, uri)
                runOnUiThread {
                    pending.add(att)
                    updateAttachLabel()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, e.message ?: "File non leggibile", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun updateAttachLabel() {
        if (pending.isEmpty()) {
            attachLabel.visibility = View.GONE
        } else {
            attachLabel.text = "📎 " + pending.joinToString(", ") { it.name }
            attachLabel.visibility = View.VISIBLE
        }
    }
}

package com.ghostbuddy

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.max

/** Trasforma un file scelto dall'utente (immagine, PDF, testo) in un blocco per l'API. */
object Attachments {

    private const val MAX_PDF_BYTES = 10 * 1024 * 1024
    private const val MAX_TEXT_CHARS = 100_000
    private const val MAX_SIDE = 1568

    fun load(cr: ContentResolver, uri: Uri): ChatStore.Attachment {
        val mime = cr.getType(uri) ?: ""
        val name = displayName(cr, uri)
        return when {
            mime.startsWith("image/") -> image(cr, uri, name)
            mime == "application/pdf" -> pdf(cr, uri, name)
            mime.startsWith("text/") -> text(cr, uri, name)
            else -> throw IllegalArgumentException("Tipo di file non supportato. Posso leggere immagini, PDF e file di testo.")
        }
    }

    private fun displayName(cr: ContentResolver, uri: Uri): String {
        val n: String? = try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
        return n ?: "file"
    }

    private fun image(cr: ContentResolver, uri: Uri, name: String): ChatStore.Attachment {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longest = max(bounds.outWidth, bounds.outHeight)
        while (longest / sample > 2048) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalArgumentException("Non riesco a leggere l'immagine.")

        // raddrizza le foto scattate in verticale
        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        var bmp: Bitmap = decoded
        if (degrees != 0f) {
            val m = Matrix()
            m.postRotate(degrees)
            bmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
        }

        val scale = MAX_SIDE.toFloat() / max(bmp.width, bmp.height)
        if (scale < 1f) {
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true
            )
        }

        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        val block = JSONObject()
            .put("type", "image")
            .put(
                "source",
                JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", b64)
            )
        return ChatStore.Attachment(name, block)
    }

    private fun pdf(cr: ContentResolver, uri: Uri, name: String): ChatStore.Attachment {
        val bytes = cr.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalArgumentException("Non riesco a leggere il PDF.")
        if (bytes.size > MAX_PDF_BYTES) throw IllegalArgumentException("PDF troppo grande (massimo 10 MB).")
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val block = JSONObject()
            .put("type", "document")
            .put(
                "source",
                JSONObject()
                    .put("type", "base64")
                    .put("media_type", "application/pdf")
                    .put("data", b64)
            )
        return ChatStore.Attachment(name, block)
    }

    private fun text(cr: ContentResolver, uri: Uri, name: String): ChatStore.Attachment {
        val content = cr.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IllegalArgumentException("Non riesco a leggere il file.")
        val block = JSONObject()
            .put("type", "text")
            .put("text", "Contenuto del file \"$name\":\n" + content.take(MAX_TEXT_CHARS))
        return ChatStore.Attachment(name, block)
    }
}

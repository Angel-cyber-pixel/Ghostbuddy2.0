package com.ghostbuddy

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(0xFF1E1B2E.toInt())
        }

        root.addView(TextView(this).apply {
            text = "GhostBuddy 👻"
            textSize = 26f
            setTextColor(Color.WHITE)
        })

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFD7D3F0.toInt())
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(status)

        root.addView(action("1. Consenti la sovrapposizione alle altre app") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(action("2. Consenti l'accesso alle notifiche") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(action("3. Niente risparmio batteria per GhostBuddy") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(TextView(this).apply {
            text = "Il fantasma guarda solo quale app ha notificato e di che tipo, mai il testo dei messaggi."
            textSize = 13f
            setTextColor(0xFF9E99C4.toInt())
            setPadding(0, dp(12), 0, dp(12))
        })

        // anteprima interna
        val preview = GhostView(this)
        root.addView(preview, LinearLayout.LayoutParams(dp(220), dp(264)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        root.addView(TextView(this).apply {
            text = "Prova le reazioni"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
        })

        val tests = listOf(
            "💘 Tinder" to GhostReaction.BLUSH,
            "📞 Chiamata" to GhostReaction.CALL,
            "😢 Chiamata persa" to GhostReaction.MISSED_CALL,
            "💬 Messaggio" to GhostReaction.MESSAGE,
            "😍 Social" to GhostReaction.SOCIAL,
            "✉️ Email" to GhostReaction.EMAIL,
            "⏰ Sveglia / evento" to GhostReaction.ALARM,
            "💰 Pagamenti" to GhostReaction.MONEY,
            "🎵 Spotify" to GhostReaction.MUSIC,
            "❗ Altro" to GhostReaction.CURIOUS,
            "😐 Calmo" to GhostReaction.IDLE
        )
        tests.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { (label, reaction) ->
                row.addView(
                    Button(this).apply {
                        text = label
                        isAllCaps = false
                        setOnClickListener {
                            preview.react(reaction)
                            GhostBus.react(reaction)
                        }
                    },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                )
            }
            root.addView(row)
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val overlayOk = Settings.canDrawOverlays(this)
        val listenerOk = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = (if (overlayOk) "✅" else "❌") + " Sovrapposizione alle app\n" +
            (if (listenerOk) "✅" else "❌") + " Accesso alle notifiche"

        if (listenerOk) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, GhostNotificationListener::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }

    private fun action(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}

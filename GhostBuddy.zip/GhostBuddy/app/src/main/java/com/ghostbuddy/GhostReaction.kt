package com.ghostbuddy

import android.app.Notification
import android.service.notification.StatusBarNotification

/** Una reazione per ogni tipo di notifica. durationMs = 0 significa "nessun limite". */
enum class GhostReaction(val durationMs: Long) {
    IDLE(0),
    BLUSH(6000),        // app di dating: arrossisce
    CALL(30000),        // chiamata in arrivo: si agita finché squilla
    MISSED_CALL(6000),  // chiamata persa: piange
    MESSAGE(5000),      // messaggio: saltella con il fumetto
    SOCIAL(5000),       // social: occhi a cuore
    EMAIL(5000),        // email: guarda la busta
    ALARM(8000),        // sveglia/calendario: sobbalza con la campanella
    MONEY(5000),        // pagamenti/banca: occhi a stella e monete
    MUSIC(6000),        // Spotify: balla
    CURIOUS(4000)       // tutto il resto: punto esclamativo
}

/** Decide la reazione guardando solo app e categoria, mai il testo della notifica. */
object ReactionMapper {
    private val DATING = listOf("tinder", "bumble", "hinge", "badoo", "happn")
    private val CLOCK = listOf("clock", "calendar", "alarm")
    private val MONEY = listOf("paypal", "revolut", "satispay", "bank", "banca", "intesa", "unicredit", "postepay")
    private val MAIL = listOf("mail", "outlook", "android.gm")
    private val MESSAGING = listOf("whatsapp", "telegram", "signal", "orca", "messaging", "mms", "sms", "discord")
    private val SOCIAL = listOf("instagram", "facebook", "musically", "tiktok", "twitter", "snapchat", "threads", "reddit")
    private val DIALER = listOf("dialer", "telecom", "incallui")

    private val IGNORED_CATEGORIES = setOf(
        Notification.CATEGORY_PROGRESS,
        Notification.CATEGORY_SERVICE,
        Notification.CATEGORY_TRANSPORT,
        Notification.CATEGORY_STATUS,
        Notification.CATEGORY_SYSTEM,
        Notification.CATEGORY_NAVIGATION,
        Notification.CATEGORY_WORKOUT
    )

    fun map(sbn: StatusBarNotification): GhostReaction? {
        val n = sbn.notification
        val p = sbn.packageName.lowercase()
        val cat: String? = n.category

        // Chiamate: squilla (full-screen o non in corso) oppure persa
        val isCallCategory = cat == Notification.CATEGORY_CALL
        if (isCallCategory && (n.fullScreenIntent != null || !sbn.isOngoing)) return GhostReaction.CALL
        if (cat == "missed_call" ||
            (!isCallCategory && !sbn.isOngoing && DIALER.any { p.contains(it) })
        ) return GhostReaction.MISSED_CALL

        // Rumore da ignorare
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        if (sbn.isOngoing) return null
        if (cat != null && cat in IGNORED_CATEGORIES) return null

        if (DATING.any { p.contains(it) }) return GhostReaction.BLUSH
        if (cat == Notification.CATEGORY_ALARM || cat == Notification.CATEGORY_REMINDER ||
            cat == Notification.CATEGORY_EVENT || CLOCK.any { p.contains(it) }
        ) return GhostReaction.ALARM
        if (MONEY.any { p.contains(it) }) return GhostReaction.MONEY
        if (cat == Notification.CATEGORY_EMAIL || MAIL.any { p.contains(it) }) return GhostReaction.EMAIL
        if (cat == Notification.CATEGORY_MESSAGE || MESSAGING.any { p.contains(it) }) return GhostReaction.MESSAGE
        if (cat == Notification.CATEGORY_SOCIAL || SOCIAL.any { p.contains(it) }) return GhostReaction.SOCIAL
        if (p.contains("spotify")) return GhostReaction.MUSIC
        return GhostReaction.CURIOUS
    }
}

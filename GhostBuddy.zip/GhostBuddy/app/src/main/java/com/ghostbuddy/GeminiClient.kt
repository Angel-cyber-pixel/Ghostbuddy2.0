package com.ghostbuddy

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Chiamata diretta a Google Gemini (piano gratuito di Google AI Studio), senza librerie esterne. */
object GeminiClient {

    private const val SYSTEM =
        "Sei GhostBuddy, un fantasmino dolce, simpatico e un po' timido che vive nell'angolo " +
            "dello schermo del tablet dell'utente. Rispondi nella lingua dell'utente, in modo chiaro, " +
            "amichevole e abbastanza breve, a meno che ti venga chiesto di approfondire."

    fun send(apiKey: String, model: String, messages: JSONArray): String {
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM)))
            )
            .put("contents", toGemini(messages))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 1500))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException(errorMessage(code, text))

            val json = JSONObject(text)
            val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
            val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            }
            if (sb.isEmpty()) {
                val reason = candidate?.optString("finishReason").orEmpty()
                throw RuntimeException("Risposta vuota ${if (reason.isEmpty()) "" else "($reason)"}. Riprova con un'altra domanda.")
            }
            return sb.toString().trim()
        } catch (e: IOException) {
            throw RuntimeException("Non riesco a connettermi a Internet (${e.message}).")
        } finally {
            conn.disconnect()
        }
    }

    /** Messaggi nel formato interno (stile Claude) -> formato Gemini. */
    private fun toGemini(messages: JSONArray): JSONArray {
        val out = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            val role = if (m.getString("role") == "assistant") "model" else "user"
            val parts = JSONArray()
            when (val content = m.get("content")) {
                is String -> parts.put(JSONObject().put("text", content))
                is JSONArray -> for (j in 0 until content.length()) {
                    val b = content.getJSONObject(j)
                    when (b.optString("type")) {
                        "text" -> parts.put(JSONObject().put("text", b.optString("text")))
                        "image", "document" -> {
                            val src = b.getJSONObject("source")
                            parts.put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", src.getString("media_type"))
                                        .put("data", src.getString("data"))
                                )
                            )
                        }
                    }
                }
            }
            out.put(JSONObject().put("role", role).put("parts", parts))
        }
        return out
    }

    private fun errorMessage(code: Int, body: String): String {
        val detail = try {
            JSONObject(body).getJSONObject("error").getString("message")
        } catch (e: Exception) {
            body.take(200)
        }
        return when (code) {
            400, 401, 403 -> "Chiave non valida o accesso negato ($code): $detail. Controllala in ⚙."
            404 -> "Modello non trovato (404). Controlla il nome del modello in ⚙."
            413 -> "Allegato troppo grande (413)."
            429 -> "Limite gratuito raggiunto per ora (429). Riprova più tardi."
            else -> "Errore $code: $detail"
        }
    }

    /**
     * Gli allegati (immagini e PDF) restano solo negli ultimi 3 messaggi:
     * quelli più vecchi diventano una nota di testo, per non sprecare il limite gratuito.
     */
    fun forRequest(all: JSONArray): JSONArray {
        val out = JSONArray()
        val keepFrom = all.length() - 3
        for (i in 0 until all.length()) {
            val m = all.getJSONObject(i)
            if (i >= keepFrom) {
                out.put(m)
                continue
            }
            val content = m.get("content")
            if (content is JSONArray) {
                val stripped = JSONArray()
                for (j in 0 until content.length()) {
                    val b = content.getJSONObject(j)
                    val t = b.optString("type")
                    if (t == "image" || t == "document") {
                        stripped.put(JSONObject().put("type", "text").put("text", "[allegato inviato prima]"))
                    } else {
                        stripped.put(b)
                    }
                }
                out.put(JSONObject().put("role", m.getString("role")).put("content", stripped))
            } else {
                out.put(m)
            }
        }
        return out
    }
}

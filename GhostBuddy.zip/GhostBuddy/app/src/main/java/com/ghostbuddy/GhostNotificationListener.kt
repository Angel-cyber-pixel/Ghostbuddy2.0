package com.ghostbuddy

import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Ascolta le notifiche di tutto il sistema e le gira al fantasma.
 * Il sistema tiene vivo questo servizio finché l'accesso alle notifiche è attivo.
 */
class GhostNotificationListener : NotificationListenerService() {

    private val overlay by lazy { GhostOverlay(this) }
    private val lastSeen = HashMap<String, Long>()
    private var ringingKey: String? = null

    override fun onListenerConnected() {
        overlay.show()
        GhostBus.overlay = overlay
    }

    override fun onListenerDisconnected() {
        GhostBus.overlay = null
        overlay.hide()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val reaction = ReactionMapper.map(sbn) ?: return

        // Le app aggiornano spesso la stessa notifica: evita di far ripartire il fantasma di continuo
        val now = SystemClock.uptimeMillis()
        val last = lastSeen[sbn.key]
        if (reaction != GhostReaction.CALL && last != null && now - last < 3000) return
        lastSeen[sbn.key] = now

        if (reaction == GhostReaction.CALL) ringingKey = sbn.key

        // Se il permesso di sovrapposizione è stato dato dopo, riprova qui
        if (overlay.show()) GhostBus.overlay = overlay
        overlay.react(reaction)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastSeen.remove(sbn.key)
        if (sbn.key == ringingKey) {
            ringingKey = null
            overlay.react(GhostReaction.IDLE)
        }
    }

    override fun onDestroy() {
        GhostBus.overlay = null
        overlay.hide()
        super.onDestroy()
    }
}
